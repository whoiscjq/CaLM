from .collision import collision

chain = collision