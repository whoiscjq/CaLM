from .collision import collision

mediation = collision