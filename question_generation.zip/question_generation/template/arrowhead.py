from .collision import collision

arrowhead = collision
