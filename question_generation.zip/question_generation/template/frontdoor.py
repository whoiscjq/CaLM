from .collision import collision

frontdoor = collision
