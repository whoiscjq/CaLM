from .collision import collision

diamondcut = collision